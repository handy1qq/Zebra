//
//  FwwTabBar.h
//  fww聊天app
//
//  Created by fengwenwei on 16/10/10.
//  Copyright © 2016年 fengwenwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FwwTabBar : NSObject

- (void )setTabBar:(UITabBarController *)tabBarController;
@end
