//
//  ZebraTableViewCell.h
//  ZebraRFD8500
//
//  Created by fengwenwei on 16/11/18.
//  Copyright © 2016年 fengwenwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZebraModel;

@interface ZebraTableViewCell : UITableViewCell

/**<#注释#> */
@property (strong, nonatomic) ZebraModel *model;


@end
