//
//  ZebraActiveScannerInfoController.h
//  ZebraRFD8500RFID&Scan
//
//  Created by fengwenwei on 16/12/12.
//  Copyright © 2016年 fengwenwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZebraActiveScannerInfoController : UITableViewController

@end
